# TudoEntregue <-> ODOO Middleware

Middleware de integracao bidirecional entre o TudoEntregue e o ODOO ERP.

## Arquitetura

```
ODOO  <---[JSON-RPC]--->  MIDDLEWARE  <---[REST API]--->  TudoEntregue
(Node.js/Express)       (Render)
                               ^
                               | Webhook POST
                               |
                          TudoEntregue
```

## Pre-requisitos

1. **Conta TudoEntregue** com AppKey e RequesterKey (Token de Integracao)
2. **ODOO** com API Key habilitada e campos Studio criados (ver secao abaixo)
3. **Node.js** 18+ e **Git**
4. **Conta Render** (deploy) ou ambiente local

## Campos a Criar no ODOO (via Studio)

### App Contatos (res.partner)
| Nome do Campo | Nome Tecnico | Tipo |
|---|---|---|
| ID Cliente TE | `x_studio_id_cliente_te` | Char |
| Enviar SMS | `x_studio_enviar_sms` | Boolean |
| Enviar Email | `x_studio_enviar_email` | Boolean |

### App Vendas (sale.order)
| Nome do Campo | Nome Tecnico | Tipo |
|---|---|---|
| Sincronizado TE | `x_studio_te_sync` | Boolean |
| ID Entrega TE | `x_studio_te_order_id` | Char |
| Codigo Rastreio | `x_studio_te_tracking_code` | Char |
| URL Rastreio | `x_studio_te_tracking_url` | Char |
| Situacao TE | `x_studio_te_situation` | Selection* |
| Ultima Sincronizacao | `x_studio_te_last_sync` | Datetime |
| Erro TE | `x_studio_te_error` | Text |
| Webhook Recebido | `x_studio_te_webhook_received` | Boolean |
| Tipo Entrega TE | `x_studio_te_delivery_type` | Selection** |

### App Estoque / Transferencias (stock.picking)
| Nome do Campo | Nome Tecnico | Tipo |
|---|---|---|
| Sincronizado TE | `x_studio_te_sync` | Boolean |
| ID Entrega TE | `x_studio_te_order_id` | Char |
| Codigo Rastreio | `x_studio_te_tracking_code` | Char |
| Situacao TE | `x_studio_te_situation` | Selection* |
| Nome Motorista | `x_studio_te_motorista` | Char |
| Telefone Motorista | `x_studio_te_fone_motorista` | Char |
| Ocorrencias | `x_studio_te_ocorrencias` | Text |
| URL Comprovante | `x_studio_te_url_comprovante` | Char |
| Ultimo Webhook | `x_studio_te_ultimo_webhook` | Datetime |
| Estado Destino | `x_studio_te_estado_destino` | Selection*** |

### App Compras (purchase.order)
| Nome do Campo | Nome Tecnico | Tipo |
|---|---|---|
| Sincronizado TE | `x_studio_te_sync` | Boolean |
| ID Entrega TE | `x_studio_te_order_id` | Char |
| Codigo Rastreio | `x_studio_te_tracking_code` | Char |
| Situacao TE | `x_studio_te_situation` | Selection* |
| Ultima Sincronizacao | `x_studio_te_last_sync` | Datetime |

### App Faturas (account.move)
| Nome do Campo | Nome Tecnico | Tipo |
|---|---|---|
| ID Entrega TE | `x_studio_te_order_id` | Char |
| Codigo Rastreio | `x_studio_te_tracking_code` | Char |
| Situacao TE | `x_studio_te_situation` | Selection* |

### Opcoes Selection

* **Situacao TE**: Aguardando(0) / Em Rota(1) / Entregue(3) / Nao Entregue(5) / Entrega Parcial(6) / Cancelada(8) / Atrasada(9) / Em Separacao(10) / Transferida(11) / Baixada(12)

** **Tipo Entrega**: Entrega(1) / Coleta(2) / Devolucao(3) / Troca(4) / Outros(5)

*** **Estado Destino**: assigned / confirmed / done / cancel

## Instalacao Local

```bash
# 1. Clone o repositorio
git clone https://github.com/SEU_USER/tudoentregue-odoo-middleware.git
cd tudoentregue-odoo-middleware

# 2. Instale dependencias
npm install

# 3. Copie e configure o .env
cp .env.example .env
# Edite o .env com suas chaves

# 4. Rode em dev
npm run dev
```

## Variaveis de Ambiente (.env)

| Variavel | Obrigatoria | Descricao |
|---|---|---|
| `TE_API_BASE_URL` | Sim | URL da API TE (default: https://api.tudoentregue.com.br) |
| `TE_APPKEY` | Sim | AppKey fornecida pela Active Corp |
| `TE_REQUESTER_KEY` | Sim | Token de Integracao do portal TE |
| `ODOO_BASE_URL` | Sim | URL do seu ODOO |
| `ODOO_DB_NAME` | Sim | Nome do banco de dados ODOO |
| `ODOO_API_KEY` | Sim | API Key do usuario ODOO |
| `API_SECRET_KEY` | Sim | Chave secreta para autenticar requests ao middleware |
| `PORT` | Nao | Porta do servidor (default: 3000) |
| `NODE_ENV` | Nao | production ou development |

## Deploy no Render

1. Faca push do projeto para um repositorio GitHub
2. Acesse [render.com](https://render.com) e crie um novo **Web Service**
3. Conecte o repositorio GitHub
4. Render detectara o `render.yaml` automaticamente
5. Preencha as env vars (TE_APPKEY, TE_REQUESTER_KEY, ODOO_*, API_SECRET_KEY)
6. Deploy automatico

### Webhook URL
Apos o deploy, configure no portal TudoEntregue:
```
https://seu-middleware.onrender.com/webhook/tudoentregue
```
Portal TE > Empresa > Integracao > Webhook

## API Endpoints

### Publicos
| Metodo | Rota | Descricao |
|---|---|---|
| GET | `/health` | Health check com status dos servicos |

### Webhook (autenticado via AppKey TE)
| Metodo | Rota | Descricao |
|---|---|---|
| POST | `/webhook/tudoentregue` | Recebe atualizacoes do TE |

### API (header `X-API-Key` obrigatorio)
| Metodo | Rota | Descricao |
|---|---|---|
| POST | `/api/deliveries/send` | Envia pedidos do ODOO ao TE |
| POST | `/api/deliveries/sync-unsynced` | Envia pedidos pendentes automaticamente |
| GET | `/api/deliveries/status/:orderNumber` | Consulta situacao de uma entrega |
| GET | `/api/deliveries/occurrences/:orderNumber` | Consulta ocorrencias |
| PUT | `/api/deliveries/edit` | Edita entregas no TE |
| DELETE | `/api/deliveries/cancel` | Cancela entregas no TE |
| GET | `/api/deliveries/situations` | Lista situacoes disponiveis |
| GET | `/api/deliveries/pull` | Puxa todas entregas e atualiza ODOO |
| GET | `/api/drivers` | Consulta motoristas |

### Exemplos de Uso

**Enviar pedido ao TE:**
```bash
curl -X POST https://seu-middleware.onrender.com/api/deliveries/send \
  -H "X-API-Key: sua_chave_secreta" \
  -H "Content-Type: application/json" \
  -d '{"pickingIds": [123, 124], "orderType": 1}'
```

**Consultar situacao:**
```bash
curl https://seu-middleware.onrender.com/api/deliveries/status/SO01234 \
  -H "X-API-Key: sua_chave_secreta"
```

**Sync automatico de pendentes:**
```bash
curl -X POST https://seu-middleware.onrender.com/api/deliveries/sync-unsynced \
  -H "X-API-Key: sua_chave_secreta" \
  -H "Content-Type: application/json" \
  -d '{"limit": 50, "orderType": 1}'
```

## Estrutura do Projeto

```
src/
  index.js              # Entry point Express
  config/
    env.js              # Variaveis de ambiente
    constants.js        # Codigos de situacao TE, limites
  middleware/
    auth.js             # Autenticacao (API key + webhook)
    errorHandler.js     # Tratamento centralizado de erros
  routes/
    delivery.js         # CRUD de entregas (ODOO <-> TE)
    driver.js           # Consulta de motoristas
    webhook.js          # Recebe webhooks do TE
    health.js           # Health check
  services/
    tudoentregue.js     # Client da API TE
    odoo.js             # Client JSON-RPC do ODOO (campos x_studio_)
    mapper.js           # Mapeamento TE <-> ODOO
  utils/
    logger.js           # Winston logger
    retry.js            # Retry com backoff exponencial
```

## Regras Importantes da API TE

- **Payload maximo:** 1MB por request
- **Maximo 50 pedidos** por request
- **Paginacao:** intervalo de 5s entre paginas
- **Situacao so pode ser consultada UMA VEZ** por mudanca de estado
- **Edicao:** campos em branco DELETAM o dado existente
- **Edicao bloqueada** apos qualquer movimentacao
- **10 paginas vazias consecutivas** = bloqueio temporario (10 min)