// ============================================================
// src/middleware/errorHandler.js — Tratamento centralizado de erros
// ============================================================
const logger = require('../utils/logger');

/**
 * Erro customizado com status code.
 */
class AppError extends Error {
  constructor(message, statusCode = 500, details = null) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Middleware Express de tratamento de erros (deve ser o ultimo middleware).
 */
function errorHandler(err, req, res, _next) {
  // Erros axios (API TE ou ODOO)
  if (err.isAxiosError) {
    const status = err.response?.status || 502;
    const teMessage = err.response?.data?.Message || err.response?.data?.error?.message;

    logger.error('Erro API externa', {
      url: err.config?.url,
      status,
      message: teMessage || err.message,
    });

    return res.status(status).json({
      error: 'Erro na comunicacao com API externa',
      message: teMessage || err.message,
      status,
    });
  }

  // Erros operacionais (AppError)
  if (err.isOperational) {
    logger.warn(err.message, { statusCode: err.statusCode, details: err.details });
    return res.status(err.statusCode).json({
      error: err.message,
      details: err.details,
      status: err.statusCode,
    });
  }

  // Erros inesperados
  logger.error('Erro inesperado', {
    message: err.message,
    stack: err.stack,
  });

  const status = err.statusCode || 500;
  return res.status(status).json({
    error: process.env.NODE_ENV === 'development' ? err.message : 'Erro interno do servidor',
    status,
  });
}

/**
 * Middleware 404 para rotas nao encontradas.
 */
function notFound(req, res) {
  res.status(404).json({
    error: 'Rota nao encontrada',
    path: req.originalUrl,
    method: req.method,
  });
}

module.exports = { AppError, errorHandler, notFound };