// ============================================================
// src/middleware/auth.js — Validacao de API key para rotas
// ============================================================
const env = require('../config/env');
const logger = require('../utils/logger');

/**
 * Middleware que valida o header X-API-Key.
 * Protege rotas que nao sao /health nem /webhook (que tem propria validacao).
 */
function apiKeyAuth(req, res, next) {
  const providedKey = req.headers['x-api-key'];

  if (!providedKey) {
    return res.status(401).json({
      error: 'API Key obrigatoria',
      message: 'Envie o header X-API-Key',
    });
  }

  if (providedKey !== env.apiSecretKey) {
    logger.warn('API Key invalida', { ip: req.ip, path: req.path });
    return res.status(403).json({
      error: 'API Key invalida',
      message: 'A chave fornecida nao e valida',
    });
  }

  next();
}

/**
 * Middleware para validar se o request vem do webhook TE.
 * O TE envia os mesmos headers (AppKey + RequesterKey) no webhook.
 */
function teWebhookAuth(req, res, next) {
  const appKey = req.headers['appkey'] || req.headers['AppKey'];
  const requesterKey = req.headers['requesterkey'] || req.headers['RequesterKey'];

  if (appKey !== env.te.appKey || requesterKey !== env.te.requesterKey) {
    logger.warn('Webhook TE: autenticacao falhou', {
      appKey: appKey ? '***' : 'ausente',
      requesterKey: requesterKey ? '***' : 'ausente',
      ip: req.ip,
    });
    return res.status(401).json({
      error: 'Autenticacao webhook falhou',
      message: 'AppKey ou RequesterKey invalido',
    });
  }

  next();
}

module.exports = { apiKeyAuth, teWebhookAuth };