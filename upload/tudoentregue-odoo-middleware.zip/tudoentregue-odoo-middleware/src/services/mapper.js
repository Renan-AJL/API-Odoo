// ============================================================
// src/services/mapper.js — Mapeamento bidirecional TE <-> ODOO
// ============================================================
const { SITUATION, SITUATION_LABELS, SITUATION_TO_ODOO_STATE, ORDER_TYPES } = require('../config/constants');
const logger = require('../utils/logger');

const Mapper = {
  // ============================================================
  // ODOO -> TudoEntregue  (para enviar pedidos do ODOO ao TE)
  // ============================================================

  /**
   * Converte um sale.order + partner do ODOO para o formato TE.
   * @param {Object} saleOrder - registro sale.order do ODOO
   * @param {Object} partner - registro res.partner do ODOO
   * @param {Object} picking - registro stock.picking (opcional)
   * @returns {Object} entrega no formato TE
   */
  odooToTeDelivery(saleOrder, partner, picking = null) {
    const stateCode = partner.state_id ? partner.state_id[1] || '' : '';
    // Pega os 2 primeiros chars do state name (sigla UF)
    const uf = stateCode.substring(0, 2).toUpperCase();

    return {
      OrderNumber: saleOrder.name || String(saleOrder.id),
      OrderType: ORDER_TYPES.ENTREGA,
      CustomerName: partner.name || '',
      DocumentNumber: partner.cnpj_cpf || partner.vat || '',
      ContactName: partner.name || '',
      Phone1: partner.phone || partner.mobile || '',
      Phone2: partner.mobile || '',
      Email: partner.email || '',
      ZipCode: (partner.zip || '').replace(/\D/g, ''),
      Address: partner.street || partner.street_name || '',
      AddressNumber: partner.street_number || '',
      Complement: '',
      Neighborhood: partner.l10n_br_district || partner.street2 || '',
      City: partner.city || '',
      State: uf,
      Country: 'Brasil',
      Latitude: partner.partner_latitude || 0,
      Longitude: partner.partner_longitude || 0,
      ScheduledDate: picking?.scheduled_date
        ? new Date(picking.scheduled_date).toISOString().split('T')[0]
        : new Date().toISOString().split('T')[0],
      ScheduledTimeStart: '08:00',
      ScheduledTimeEnd: '18:00',
      Description: saleOrder.note || `Pedido ODOO #${saleOrder.name}`,
      Quantity: picking?.move_line_count || 1,
      Volume: 1,
      Weight: 0,
      Value: saleOrder.amount_total || 0,
      SendSMS: partner.te_send_sms || false,
      SendEmail: partner.te_send_email || false,
      VehicleTypeId: 0,
      CategoryId: 0,
      DeliveryMethodId: 0,
      Reference1: String(saleOrder.id),
      Reference2: partner.id ? String(partner.id) : '',
      Reference3: picking ? String(picking.id) : '',
    };
  },

  /**
   * Converte lote de picking do ODOO para lote TE.
   * @param {Array} pickings - array de { picking, saleOrder, partner }
   * @returns {Array} entregas TE
   */
  odooPickingsToTeDeliveries(pickings) {
    return pickings.map(({ picking, saleOrder, partner }) =>
      this.odooToTeDelivery(saleOrder, partner, picking)
    );
  },

  // ============================================================
  // TudoEntregue -> ODOO  (para atualizar ODOO com dados do TE)
  // ============================================================

  /**
   * Extrai dados relevantes do TE para atualizar stock.picking no ODOO.
   * @param {Object} teDelivery - item retornado pela API TE
   * @returns {Object} dados para updatePickingTeData
   */
  teToOdooPicking(teDelivery) {
    const situationCode = teDelivery.Situation ?? teDelivery.situation ?? null;
    const odoOState = situationCode !== null
      ? (SITUATION_TO_ODOO_STATE[situationCode] || null)
      : null;

    return {
      situation: situationCode,
      situationLabel: situationCode !== null
        ? (SITUATION_LABELS[situationCode] || `Situacao ${situationCode}`)
        : null,
      trackingCode: teDelivery.TrackingCode || teDelivery.trackingCode || '',
      driverName: teDelivery.DriverName || teDelivery.driverName || '',
      driverPhone: teDelivery.DriverPhone || teDelivery.driverPhone || '',
      odoOState,
      occurrences: teDelivery.Occurrences || [],
      proofUrl: teDelivery.ProofUrl || teDelivery.proofUrl || '',
      teOrderId: teDelivery.OrderNumber || teDelivery.orderNumber || '',
      orderType: teDelivery.OrderType || teDelivery.orderType,
      customerId: teDelivery.CustomerId || teDelivery.customerId,
    };
  },

  /**
   * Extrai dados do TE para atualizar sale.order no ODOO.
   * @param {Object} teDelivery
   * @returns {Object}
   */
  teToOdooSaleOrder(teDelivery) {
    const situationCode = teDelivery.Situation ?? teDelivery.situation ?? null;

    return {
      situation: situationCode,
      situationLabel: situationCode !== null
        ? (SITUATION_LABELS[situationCode] || `Situacao ${situationCode}`)
        : null,
      trackingCode: teDelivery.TrackingCode || teDelivery.trackingCode || '',
      trackingUrl: this._buildTrackingUrl(teDelivery),
      teOrderId: teDelivery.OrderNumber || teDelivery.orderNumber || '',
    };
  },

  // ============================================================
  // HELPERS
  // ============================================================

  /**
   * Constroi URL de rastreamento TE (formato do portal).
   */
  _buildTrackingUrl(teDelivery) {
    const code = teDelivery.TrackingCode || teDelivery.trackingCode;
    if (!code) return '';
    return `https://app.tudoentregue.com.br/rastreamento/${code}`;
  },

  /**
   * Normaliza uma entrega webhook TE para formato padrao.
   * O webhook TE envia o mesmo formato do response de consulta.
   */
  normalizeWebhookPayload(payload) {
    // Pode vir como array ou objeto unico
    const deliveries = Array.isArray(payload) ? payload : [payload];
    return deliveries.map((d) => ({
      orderNumber: d.OrderNumber || d.orderNumber,
      orderType: d.OrderType || d.orderType,
      situation: d.Situation ?? d.situation,
      trackingCode: d.TrackingCode || d.trackingCode || '',
      driverName: d.DriverName || d.driverName || '',
      driverPhone: d.DriverPhone || d.driverPhone || '',
      customerId: d.CustomerId || d.customerId,
      customerName: d.CustomerName || d.customerName || '',
      occurrenceDescription: d.OccurrenceDescription || d.occurrenceDescription || '',
      occurrenceDate: d.OccurrenceDate || d.occurrenceDate || '',
      occurrences: d.Occurrences || [],
      proofUrl: d.ProofUrl || d.proofUrl || '',
      deliveredDate: d.DeliveredDate || d.deliveredDate || '',
      canceledDate: d.CanceledDate || d.canceledDate || '',
      raw: d,
    }));
  },
};

module.exports = Mapper;