// ============================================================
// src/services/tudoentregue.js — Client completo da API TE
// ============================================================
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const env = require('../config/env');
const { API_LIMITS, SITUATION, SITUATION_LABELS } = require('../config/constants');
const logger = require('../utils/logger');
const { retryWithBackoff } = require('../utils/retry');

class TudoEntregueClient {
  constructor() {
    this.httpClient = axios.create({
      baseURL: env.te.baseUrl,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        'AppKey': env.te.appKey,
        'RequesterKey': env.te.requesterKey,
      },
    });

    // Interceptor para log de requests
    this.httpClient.interceptors.request.use((cfg) => {
      logger.debug(`TE Request: ${cfg.method?.toUpperCase()} ${cfg.url}`, {
        params: cfg.params,
      });
      return cfg;
    });

    // Interceptor para log de erros
    this.httpClient.interceptors.response.use(
      (res) => res,
      (err) => {
        const msg = err.response?.data?.Message || err.message;
        logger.error(`TE Error: ${err.config?.url} — ${msg}`, {
          status: err.response?.status,
          data: err.response?.data,
        });
        return Promise.reject(err);
      }
    );
  }

  // -------------------------------------------------------
  // HELPER — valida payload < 1MB
  // -------------------------------------------------------
  _validatePayload(data) {
    const bytes = Buffer.byteLength(JSON.stringify(data), 'utf-8');
    if (bytes > API_LIMITS.MAX_PAYLOAD_BYTES) {
      throw new Error(`Payload excede 1MB (${(bytes / 1024).toFixed(0)}KB). Divida em lotes menores.`);
    }
  }

  // -------------------------------------------------------
  // HELPER — envia com retry (nao retry em 4xx exceto 429)
  // -------------------------------------------------------
  async _request(method, url, data = null, params = null) {
    return retryWithBackoff(
      () => this.httpClient.request({ method, url, data, params }),
      {
        maxRetries: 3,
        shouldRetry: (err) => {
          const status = err.response?.status;
          return !status || status >= 500 || status === 429;
        },
      }
    );
  }

  // ============================================================
  // ENDPOINTS OFICIAIS DA API
  // ============================================================

  // -------------------------------------------------------
  // 1. CADASTRO DE ENTREGAS  (POST /api/Entregas/Cadastro)
  // -------------------------------------------------------
  /**
   * Envia entregas para o TudoEntregue.
   * @param {Array<Object>} deliveries - array de entregas (max 50)
   *   Cada entrega:
   *   {
   *     OrderNumber: string (obrigatorio, unico com OrderType),
   *     OrderType: number (1=Entrega,2=Coleta,3=Devolucao,4=Troca,5=Outros),
   *     CustomerName: string,
   *     DocumentNumber: string (CPF/CNPJ),
   *     ContactName: string,
   *     Phone1: string,
   *     Phone2: string,
   *     Email: string,
   *     ZipCode: string (CEP),
   *     Address: string,
   *     AddressNumber: string,
   *     Complement: string,
   *     Neighborhood: string,
   *     City: string,
   *     State: string,
   *     Country: string,
   *     Latitude: number,
   *     Longitude: number,
   *     ScheduledDate: string (YYYY-MM-DD),
   *     ScheduledTimeStart: string (HH:mm),
   *     ScheduledTimeEnd: string (HH:mm),
   *     Description: string (obs da entrega),
   *     Quantity: number,
   *     Volume: number,
   *     Weight: number,
   *     Value: number,
   *     SendSMS: boolean,
   *     SendEmail: boolean,
   *     VehicleTypeId: number,
   *     CategoryId: number,
   *     DeliveryMethodId: number,
   *     Reference1: string,
   *     Reference2: string,
   *     Reference3: string
   *   }
   * @returns {Object} { Id: number, Message: string, ValidationMessages: [] }
   */
  async createDeliveries(deliveries) {
    if (!Array.isArray(deliveries)) {
      deliveries = [deliveries];
    }
    if (deliveries.length > API_LIMITS.MAX_ORDERS_PER_REQUEST) {
      throw new Error(`Maximo ${API_LIMITS.MAX_ORDERS_PER_REQUEST} entregas por request. Enviado: ${deliveries.length}`);
    }
    this._validatePayload(deliveries);

    const { data } = await this._request('POST', '/api/Entregas/Cadastro', deliveries);
    logger.info(`TE Cadastro: ${deliveries.length} entregas enviadas`, { result: data });
    return data;
  }

  // -------------------------------------------------------
  // 2. EDICAO DE ENTREGAS  (PUT /api/Entregas/Edicao)
  // -------------------------------------------------------
  /**
   * Edita entregas existentes. Regra TE:
   * - Apenas entregas sem movimentacao podem ser editadas
   * - Campos enviados em branco DELETAM o dado existente
   * - OrderNumber e OrderType nao podem ser alterados
   * @param {Array<Object>} deliveries - mesmo formato do cadastro, incluindo OrderNumber e OrderType
   * @returns {Object} { Message: string, ValidationMessages: [] }
   */
  async editDeliveries(deliveries) {
    if (!Array.isArray(deliveries)) {
      deliveries = [deliveries];
    }
    if (deliveries.length > API_LIMITS.MAX_ORDERS_PER_REQUEST) {
      throw new Error(`Maximo ${API_LIMITS.MAX_ORDERS_PER_REQUEST} entregas por edicao. Enviado: ${deliveries.length}`);
    }
    this._validatePayload(deliveries);

    const { data } = await this._request('PUT', '/api/Entregas/Edicao', deliveries);
    logger.info(`TE Edicao: ${deliveries.length} entregas editadas`, { result: data });
    return data;
  }

  // -------------------------------------------------------
  // 3. CANCELAR ENTREGAS  (DELETE /api/Entregas/Cancelamento)
  // -------------------------------------------------------
  /**
   * Cancela entregas. Regra TE:
   * - Apenas entregas sem movimentacao podem ser canceladas
   * @param {Array<Object>} orders - [{ OrderNumber, OrderType }]
   * @returns {Object}
   */
  async cancelDeliveries(orders) {
    if (!Array.isArray(orders)) {
      orders = [orders];
    }
    const { data } = await this._request('DELETE', '/api/Entregas/Cancelamento', orders);
    logger.info(`TE Cancelamento: ${orders.length} entregas canceladas`, { result: data });
    return data;
  }

  // -------------------------------------------------------
  // 4. CONSULTA DE ENTREGAS  (GET /api/Entregas)
  // -------------------------------------------------------
  /**
   * Consulta entregas com filtros.
   * @param {Object} params
   * @param {number} params.page - pagina (1-based)
   * @param {string} [params.orderNumber] - filtro por numero pedido
   * @param {number} [params.orderType] - 1,2,3,4,5
   * @param {number} [params.situation] - codigo situacao (0-12)
   * @param {string} [params.dateFrom] - data inicial (YYYY-MM-DD)
   * @param {string} [params.dateTo] - data final (YYYY-MM-DD)
   * @returns {Object} { HasNextPage: bool, Result: [...] }
   */
  async getDeliveries(params = {}) {
    const { data } = await this._request('GET', '/api/Entregas', null, {
      page: 1,
      ...params,
    });
    return data;
  }

  // -------------------------------------------------------
  // 5. CONSULTA COM OCORRENCIA  (GET /api/Entregas/Ocorrencia)
  // -------------------------------------------------------
  /**
   * Consulta entregas que possuem ocorrencia.
   * @param {Object} params - mesmos filtros de getDeliveries
   * @returns {Object} { HasNextPage: bool, Result: [...] }
   *
   * IMPORTANTE: Cada mudanca de situacao so pode ser consultada UMA VEZ.
   * Estrutura do item inclui: OccurrenceDescription, OccurrenceDate, etc.
   */
  async getDeliveriesWithOccurrence(params = {}) {
    const { data } = await this._request('GET', '/api/Entregas/Ocorrencia', null, {
      page: 1,
      ...params,
    });
    return data;
  }

  // -------------------------------------------------------
  // 6. CONSULTA SITUACOES  (GET /api/Entregas/Situacao)
  // -------------------------------------------------------
  /**
   * Lista todas as situacoes disponiveis.
   * @returns {Array<{ Id: number, Description: string }>}
   */
  async getSituations() {
    const { data } = await this._request('GET', '/api/Entregas/Situacao');
    return data;
  }

  // -------------------------------------------------------
  // PAGINACAO AUTOMATICA
  // -------------------------------------------------------
  /**
   * Busca TODAS as paginas de uma consulta, respeitando intervalo de 5s.
   * @param {string} endpoint - '/api/Entregas' ou '/api/Entregas/Ocorrencia'
   * @param {Object} params - filtros
   * @returns {Array} todas as entregas de todas as paginas
   */
  async fetchAllPages(endpoint, params = {}) {
    const allResults = [];
    let page = 1;
    let emptyCount = 0;

    while (true) {
      const response = await this._request('GET', endpoint, null, { ...params, page });
      const items = response.data?.Result || [];

      if (items.length === 0) {
        emptyCount++;
        if (emptyCount >= env.te.maxEmptyPages || !response.data?.HasNextPage) break;
      } else {
        emptyCount = 0;
        allResults.push(...items);
      }

      if (!response.data?.HasNextPage) break;

      page++;
      // Respeita intervalo de paginacao da API
      if (page > 1) {
        logger.debug(`TE Paginacao: esperando ${env.te.pageIntervalMs}ms antes da pagina ${page}`);
        await new Promise((r) => setTimeout(r, env.te.pageIntervalMs));
      }
    }

    logger.info(`TE Paginacao finalizada: ${allResults.length} itens em ${page} paginas`);
    return allResults;
  }
}

module.exports = new TudoEntregueClient();