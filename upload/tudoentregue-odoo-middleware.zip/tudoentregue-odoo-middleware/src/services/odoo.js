// ============================================================
// src/services/odoo.js — Client JSON-RPC do ODOO
// Campos x_studio_ conforme definido para ODOO Studio
// ============================================================
const axios = require('axios');
const env = require('../config/env');
const logger = require('../utils/logger');
const { retryWithBackoff } = require('../utils/retry');

const JSON_RPC_URL = '/jsonrpc';

// -------------------------------------------------------
// Nomes dos campos Studio (x_studio_) usados no ODOO
// -------------------------------------------------------
const FIELDS = {
  'res.partner': {
    teCustomerId:   'x_studio_id_cliente_te',
    teSendSms:      'x_studio_enviar_sms',
    teSendEmail:    'x_studio_enviar_email',
  },
  'sale.order': {
    teSync:         'x_studio_te_sync',
    teOrderId:      'x_studio_te_order_id',
    teTrackingCode: 'x_studio_te_tracking_code',
    teTrackingUrl:  'x_studio_te_tracking_url',
    teSituation:    'x_studio_te_situation',
    teLastSync:     'x_studio_te_last_sync',
    teError:        'x_studio_te_error',
    teWebhook:      'x_studio_te_webhook_received',
    teDeliveryType: 'x_studio_te_delivery_type',
  },
  'stock.picking': {
    teSync:            'x_studio_te_sync',
    teOrderId:         'x_studio_te_order_id',
    teTrackingCode:    'x_studio_te_tracking_code',
    teSituation:       'x_studio_te_situation',
    teDriverName:      'x_studio_te_motorista',
    teDriverPhone:     'x_studio_te_fone_motorista',
    teOccurrences:     'x_studio_te_ocorrencias',
    teProofUrl:        'x_studio_te_url_comprovante',
    teLastWebhook:     'x_studio_te_ultimo_webhook',
    teSituationTarget: 'x_studio_te_estado_destino',
  },
  'purchase.order': {
    teSync:         'x_studio_te_sync',
    teOrderId:      'x_studio_te_order_id',
    teTrackingCode: 'x_studio_te_tracking_code',
    teSituation:    'x_studio_te_situation',
    teLastSync:     'x_studio_te_last_sync',
  },
  'account.move': {
    teOrderId:      'x_studio_te_order_id',
    teTrackingCode: 'x_studio_te_tracking_code',
    teSituation:    'x_studio_te_situation',
  },
};

class OdooClient {
  constructor() {
    this.baseUrl = env.odoo.baseUrl.replace(/\/+$/, '');
    this.db = env.odoo.db;
    this.apiKey = env.odoo.apiKey;
    this.uid = null;

    this.httpClient = axios.create({
      baseURL: this.baseUrl,
      timeout: 30000,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // -------------------------------------------------------
  // Autenticacao
  // -------------------------------------------------------
  async authenticate() {
    try {
      const result = await this._jsonRpc('common', 'authenticate', {
        db: this.db,
        login: '__system__',
        password: this.apiKey,
      });
      this.uid = result;
      logger.info(`ODOO autenticado: uid=${this.uid}`);
      return this.uid;
    } catch (err) {
      logger.warn('Autenticacao ODOO via authenticate falhou, usando fallback');
      this.uid = 1;
      return this.uid;
    }
  }

  // -------------------------------------------------------
  // JSON-RPC generico
  // -------------------------------------------------------
  async _jsonRpc(model, method, args = {}, kwargs = {}) {
    const payload = {
      jsonrpc: '2.0',
      method: 'call',
      id: Date.now(),
      params: {
        service: 'object',
        method: 'execute_kw',
        args: [
          this.db,
          this.uid || 1,
          this.apiKey,
          model,
          method,
          typeof args === 'object' && !Array.isArray(args) ? [args] : args,
          kwargs,
        ],
      },
    };

    const { data } = await retryWithBackoff(
      () => this.httpClient.post(JSON_RPC_URL, payload),
      {
        maxRetries: 3,
        shouldRetry: (err) => {
          const s = err.response?.status;
          return !s || s >= 500;
        },
      }
    );

    if (data.error) {
      logger.error(`ODOO RPC Error: ${data.error.message || JSON.stringify(data.error)}`);
      throw new Error(data.error.message || 'Erro ODOO RPC');
    }

    return data.result;
  }

  // -------------------------------------------------------
  // Metodos CRUD genericos
  // -------------------------------------------------------
  async searchRead(model, domain = [], fields = [], limit = 0, offset = 0, order = '') {
    const kwargs = { fields, limit, offset };
    if (order) kwargs.order = order;
    return this._jsonRpc(model, 'search_read', domain, kwargs);
  }

  async search(model, domain = [], limit = 0, offset = 0) {
    return this._jsonRpc(model, 'search', domain, { limit, offset });
  }

  async read(model, ids, fields = []) {
    return this._jsonRpc(model, 'read', ids, { fields });
  }

  async create(model, values) {
    const id = await this._jsonRpc(model, 'create', values);
    logger.info(`ODOO Create ${model}: id=${id}`);
    return id;
  }

  async write(model, ids, values) {
    const result = await this._jsonRpc(model, 'write', ids, values);
    logger.info(`ODOO Write ${model}: ids=${JSON.stringify(ids)}`);
    return result;
  }

  // -------------------------------------------------------
  // HELPERS para buscar campos Studio
  // -------------------------------------------------------
  _f(model, key) {
    return FIELDS[model]?.[key] || key;
  }

  getStudioFields(model) {
    return Object.values(FIELDS[model] || {});
  }

  // -------------------------------------------------------
  // SALE.ORDER
  // -------------------------------------------------------

  async findSaleOrderByTeId(teOrderId) {
    const f = FIELDS['sale.order'];
    const results = await this.searchRead(
      'sale.order',
      [[f.teOrderId, '=', teOrderId]],
      ['id', 'name', 'state', 'partner_id', f.teSync, f.teSituation, f.teTrackingCode]
    );
    return results.length > 0 ? results[0] : null;
  }

  async updateSaleOrderTeData(orderId, teData) {
    const f = FIELDS['sale.order'];
    const values = {
      [f.teLastSync]: new Date().toISOString(),
      [f.teSync]: true,
    };

    if (teData.situation !== undefined) values[f.teSituation] = teData.situation;
    if (teData.situationLabel) values[`${f.teSituation}_label`] = teData.situationLabel;
    if (teData.trackingCode) values[f.teTrackingCode] = teData.trackingCode;
    if (teData.trackingUrl) values[f.teTrackingUrl] = teData.trackingUrl;
    if (teData.error) values[f.teError] = teData.error;
    if (teData.webhookReceived !== undefined) values[f.teWebhook] = teData.webhookReceived;

    return this.write('sale.order', [orderId], values);
  }

  /**
   * Marca pedidos de venda como sincronizados com o TE
   */
  async markSaleOrdersSynced(orderIds, teOrderId, orderType) {
    const f = FIELDS['sale.order'];
    return this.write('sale.order', orderIds, {
      [f.teSync]: true,
      [f.teOrderId]: teOrderId,
      [f.teLastSync]: new Date().toISOString(),
      [f.teDeliveryType]: orderType,
      [f.teError]: false,
    });
  }

  /**
   * Marca erro de sincronizacao no pedido de venda
   */
  async markSaleOrderError(orderId, errorMessage) {
    const f = FIELDS['sale.order'];
    return this.write('sale.order', [orderId], {
      [f.teSync]: false,
      [f.teError]: errorMessage,
      [f.teLastSync]: new Date().toISOString(),
    });
  }

  // -------------------------------------------------------
  // STOCK.PICKING
  // -------------------------------------------------------

  async findPickingByTeId(teOrderId) {
    const f = FIELDS['stock.picking'];
    const results = await this.searchRead(
      'stock.picking',
      [[f.teOrderId, '=', teOrderId]],
      ['id', 'name', 'state', 'partner_id', f.teSync, f.teSituation, f.teTrackingCode]
    );
    return results.length > 0 ? results[0] : null;
  }

  async updatePickingTeData(pickingId, teData) {
    const f = FIELDS['stock.picking'];
    const values = {
      [f.teLastWebhook]: new Date().toISOString(),
      [f.teSync]: true,
    };

    if (teData.situation !== undefined) values[f.teSituation] = teData.situation;
    if (teData.trackingCode) values[f.teTrackingCode] = teData.trackingCode;
    if (teData.driverName) values[f.teDriverName] = teData.driverName;
    if (teData.driverPhone) values[f.teDriverPhone] = teData.driverPhone;
    if (teData.occurrences && teData.occurrences.length > 0) {
      values[f.teOccurrences] = JSON.stringify(teData.occurrences);
    }
    if (teData.proofUrl) values[f.teProofUrl] = teData.proofUrl;
    if (teData.odoOState) values[f.teSituationTarget] = teData.odoOState;

    return this.write('stock.picking', [pickingId], values);
  }

  /**
   * Marca pickings como sincronizados
   */
  async markPickingsSynced(pickingIds, teOrderId) {
    const f = FIELDS['stock.picking'];
    return this.write('stock.picking', pickingIds, {
      [f.teSync]: true,
      [f.teOrderId]: teOrderId,
    });
  }

  // -------------------------------------------------------
  // PURCHASE.ORDER
  // -------------------------------------------------------

  async findPurchaseOrderByTeId(teOrderId) {
    const f = FIELDS['purchase.order'];
    const results = await this.searchRead(
      'purchase.order',
      [[f.teOrderId, '=', teOrderId]],
      ['id', 'name', 'state', 'partner_id', f.teSync, f.teSituation]
    );
    return results.length > 0 ? results[0] : null;
  }

  async updatePurchaseOrderTeData(orderId, teData) {
    const f = FIELDS['purchase.order'];
    const values = {
      [f.teLastSync]: new Date().toISOString(),
      [f.teSync]: true,
    };
    if (teData.situation !== undefined) values[f.teSituation] = teData.situation;
    if (teData.trackingCode) values[f.teTrackingCode] = teData.trackingCode;
    return this.write('purchase.order', [orderId], values);
  }

  // -------------------------------------------------------
  // ACCOUNT.MOVE (Faturas)
  // -------------------------------------------------------

  async updateInvoiceTeData(moveId, teData) {
    const f = FIELDS['account.move'];
    const values = {};
    if (teData.teOrderId) values[f.teOrderId] = teData.teOrderId;
    if (teData.trackingCode) values[f.teTrackingCode] = teData.trackingCode;
    if (teData.situation !== undefined) values[f.teSituation] = teData.situation;
    return this.write('account.move', [moveId], values);
  }

  // -------------------------------------------------------
  // RES.PARTNER (Contatos)
  // -------------------------------------------------------

  async findPartnerByDocument(document) {
    const cleaned = (document || '').replace(/\D/g, '');
    if (!cleaned) return null;

    // Tenta buscar pelo campo cnpj_cpf (modulo l10n_br) ou vat
    const f = FIELDS['res.partner'];
    let results = await this.searchRead(
      'res.partner',
      [['cnpj_cpf', '=', cleaned]],
      ['id', 'name', 'cnpj_cpf', 'phone', 'mobile', 'email', f.teCustomerId, f.teSendSms, f.teSendEmail]
    );

    if (results.length === 0) {
      // Fallback: busca pelo vat
      results = await this.searchRead(
        'res.partner',
        [['vat', '=', cleaned]],
        ['id', 'name', 'vat', 'phone', 'mobile', 'email', f.teCustomerId, f.teSendSms, f.teSendEmail]
      );
    }

    return results.length > 0 ? results[0] : null;
  }

  async createPartner(data) {
    const cleaned = (data.DocumentNumber || '').replace(/\D/g, '');
    const f = FIELDS['res.partner'];
    const values = {
      name: data.CustomerName || data.ContactName || 'Cliente TE',
      phone: data.Phone1 || '',
      mobile: data.Phone2 || '',
      email: data.Email || '',
      street: data.Address || '',
      street_number: data.AddressNumber || '',
      zip: data.ZipCode || '',
      city: data.City || '',
      customer_rank: 1,
    };

    // Tenta usar cnpj_cpf se o modulo BR estiver instalado
    if (cleaned) {
      values.cnpj_cpf = cleaned;
    }

    // Campos Studio TE
    values[f.teCustomerId] = data.CustomerId || false;
    values[f.teSendSms] = data.SendSMS || false;
    values[f.teSendEmail] = data.SendEmail || false;

    return this.create('res.partner', values);
  }

  // -------------------------------------------------------
  // BUSCA PEDIDOS NAO SINCRONIZADOS (para enviar ao TE)
  // -------------------------------------------------------

  /**
   * Busca pickings confirmados/atribuidos que ainda nao foram enviados ao TE
   * @param {number} limit
   * @returns {Array}
   */
  async getUnsyncedPickings(limit = 50) {
    const f = FIELDS['stock.picking'];
    const soFields = FIELDS['sale.order'];

    return this.searchRead(
      'stock.picking',
      [
        ['picking_type_code', '=', 'outgoing'],
        ['state', 'in', ['assigned', 'confirmed']],
        [f.teSync, '=', false],
        [f.teOrderId, '=', false],
      ],
      [
        'id', 'name', 'state', 'partner_id', 'scheduled_date',
        'move_line_count', 'origin',
        f.teSync, f.teOrderId,
      ],
      limit
    );
  }

  /**
   * Busca pedidos de venda nao sincronizados com o TE
   * @param {number} limit
   * @returns {Array}
   */
  async getUnsyncedSaleOrders(limit = 50) {
    const f = FIELDS['sale.order'];
    return this.searchRead(
      'sale.order',
      [
        ['state', 'in', ['sale', 'done']],
        [f.teSync, '=', false],
        [f.teOrderId, '=', false],
      ],
      [
        'id', 'name', 'state', 'partner_id', 'amount_total', 'note',
        f.teSync, f.teOrderId, f.teError,
      ],
      limit
    );
  }
}

module.exports = new OdooClient();