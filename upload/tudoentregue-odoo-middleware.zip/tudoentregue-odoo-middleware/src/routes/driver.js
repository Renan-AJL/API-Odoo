// ============================================================
// src/routes/driver.js — Rotas de consulta de motoristas TE
// ============================================================
const express = require('express');
const router = express.Router();
const teClient = require('../services/tudoentregue');
const logger = require('../utils/logger');
const { AppError } = require('../middleware/errorHandler');

// -------------------------------------------------------
// GET /api/drivers — Consulta motoristas no TE
// -------------------------------------------------------
// Query params: page, driverName, documentNumber
router.get('/', async (req, res, next) => {
  try {
    const { page = 1, driverName, documentNumber } = req.query;

    const params = { page: parseInt(page, 10) };
    if (driverName) params.driverName = driverName;
    if (documentNumber) params.documentNumber = documentNumber;

    // Usa o client generico para buscar motoristas
    // (endpoint conforme documentacao TE)
    const response = await teClient._request(
      'GET', '/api/Motoristas', null, params
    );

    res.json({
      success: true,
      drivers: response.data?.Result || response.data || [],
      hasNextPage: response.data?.HasNextPage || false,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;