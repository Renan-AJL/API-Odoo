// ============================================================
// src/routes/webhook.js — Recebe webhooks do TudoEntregue
// ============================================================
const express = require('express');
const router = express.Router();
const odooClient = require('../services/odoo');
const Mapper = require('../services/mapper');
const logger = require('../utils/logger');
const { SITUATION, FINAL_SITUATIONS, SITUATION_LABELS } = require('../config/constants');

// Autenticacao via headers TE (AppKey + RequesterKey)
// Removido daqui e aplicado no index.js via teWebhookAuth
// para poder desabilitar em dev se necessario

/**
 * POST /webhook/tudoentregue
 * Recebe atualizacao de situacao do TE.
 * O TE envia o mesmo formato do response de "Consulta de Entregas com Ocorrencia".
 */
router.post('/tudoentregue', async (req, res, next) => {
  try {
    const payload = req.body;

    logger.info('Webhook TE recebido', {
      type: Array.isArray(payload) ? `array[${payload.length}]` : 'object',
    });

    // Normaliza o payload (pode vir array ou objeto)
    const deliveries = Mapper.normalizeWebhookPayload(payload);

    const results = [];

    for (const d of deliveries) {
      const result = await processWebhookDelivery(d);
      results.push(result);
    }

    // Sempre retorna 200 para o TE nao retry
    res.json({
      success: true,
      processed: results.length,
      results,
    });
  } catch (err) {
    logger.error('Erro no webhook TE', { error: err.message, stack: err.stack });
    // Mesmo com erro, retorna 200 para o TE nao fazer retry infinito
    res.status(200).json({
      success: false,
      error: err.message,
    });
  }
});

// -------------------------------------------------------
// Processamento individual de cada entrega do webhook
// -------------------------------------------------------
async function processWebhookDelivery(delivery) {
  const { orderNumber, situation, trackingCode, driverName, driverPhone,
          occurrenceDescription, occurrenceDate, proofUrl } = delivery;

  if (!orderNumber) {
    return { orderNumber: 'desconhecido', status: 'ignored', reason: 'sem OrderNumber' };
  }

  const situationLabel = situation !== null && situation !== undefined
    ? (SITUATION_LABELS[situation] || `Situacao ${situation}`)
    : null;

  logger.info(`Processando webhook: ${orderNumber} -> situacao ${situation} (${situationLabel})`);

  // 1. Tenta encontrar stock.picking
  const picking = await odooClient.findPickingByTeId(orderNumber);

  if (picking) {
    const mapped = Mapper.teToOdooPicking(delivery.raw || delivery);
    await odooClient.updatePickingTeData(picking.id, mapped);
    logger.info(`Picking ${picking.name} (id=${picking.id}) atualizado: ${situationLabel}`);
  }

  // 2. Tenta encontrar sale.order
  const saleOrder = await odooClient.findSaleOrderByTeId(orderNumber);

  if (saleOrder) {
    await odooClient.updateSaleOrderTeData(saleOrder.id, {
      situation,
      situationLabel,
      trackingCode,
      trackingUrl: Mapper._buildTrackingUrl(delivery.raw || delivery),
      webhookReceived: true,
    });
    logger.info(`Sale Order ${saleOrder.name} (id=${saleOrder.id}) atualizado`);

    // Se for compra, atualiza tambem
    const purchaseOrder = await odooClient.findPurchaseOrderByTeId(orderNumber);
    if (purchaseOrder) {
      await odooClient.updatePurchaseOrderTeData(purchaseOrder.id, {
        situation,
        trackingCode,
      });
    }
  }

  const found = !!(picking || saleOrder);

  if (!found) {
    logger.warn(`Webhook: ${orderNumber} nao encontrado no ODOO (picking ou sale.order)`);
  }

  return {
    orderNumber,
    situation,
    situationLabel,
    trackingCode,
    driverName,
    pickingUpdated: !!picking,
    saleOrderUpdated: !!saleOrder,
    found,
  };
}

module.exports = router;