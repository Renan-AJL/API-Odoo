// ============================================================
// src/routes/delivery.js — Rotas de entrega (ODOO -> TE e TE -> ODOO)
// ============================================================
const express = require('express');
const router = express.Router();
const teClient = require('../services/tudoentregue');
const odooClient = require('../services/odoo');
const Mapper = require('../services/mapper');
const logger = require('../utils/logger');
const { AppError } = require('../middleware/errorHandler');
const { SITUATION_LABELS, FINAL_SITUATIONS } = require('../config/constants');

// -------------------------------------------------------
// POST /api/deliveries/send — Envia pedidos do ODOO ao TE
// -------------------------------------------------------
// Body: { orderIds?: number[], pickingIds?: number[], orderType?: 1|2|3|4|5 }
router.post('/send', async (req, res, next) => {
  try {
    const { orderIds, pickingIds, orderType = 1 } = req.body;

    if (!orderIds?.length && !pickingIds?.length) {
      throw new AppError('Informe orderIds ou pickingIds', 400);
    }

    // 1. Busca pedidos ODOO
    const pickings = [];
    const saleOrders = [];

    if (pickingIds?.length) {
      const found = await odooClient.read('stock.picking', pickingIds, [
        'id', 'name', 'partner_id', 'scheduled_date', 'move_line_count', 'origin',
      ]);
      pickings.push(...found);
    }

    if (orderIds?.length) {
      const soFields = odooClient.getStudioFields('sale.order');
      const found = await odooClient.read('sale.order', orderIds, [
        'id', 'name', 'state', 'partner_id', 'amount_total', 'note', ...soFields,
      ]);
      saleOrders.push(...found);
    }

    // 2. Busca parceiros e mapeia para formato TE
    const partnerIds = [
      ...pickings.map(p => p.partner_id?.[0]),
      ...saleOrders.map(o => o.partner_id?.[0]),
    ].filter(Boolean);

    const partners = partnerIds.length > 0
      ? await odooClient.read('res.partner', [...new Set(partnerIds)], [
          'id', 'name', 'cnpj_cpf', 'vat', 'phone', 'mobile', 'email',
          'street', 'street_number', 'street2', 'zip', 'city',
          'l10n_br_district', 'partner_latitude', 'partner_longitude',
          'state_id', 'country_id',
          ...odooClient.getStudioFields('res.partner'),
        ])
      : [];

    const partnerMap = {};
    partners.forEach(p => { partnerMap[p.id] = p; });

    // 3. Mapeia para entregas TE
    const teDeliveries = [];

    for (const so of saleOrders) {
      const partner = partnerMap[so.partner_id?.[0]] || {};
      // Busca picking vinculado se existir
      const picking = pickings.find(p => p.origin === so.name) || null;
      const teDelivery = Mapper.odooToTeDelivery(so, partner, picking);
      teDelivery.OrderType = orderType;
      teDeliveries.push(teDelivery);
    }

    for (const picking of pickings) {
      const partner = partnerMap[picking.partner_id?.[0]] || {};
      const fakeSo = { name: picking.origin || `WH-${picking.id}`, note: '' };
      const teDelivery = Mapper.odooToTeDelivery(fakeSo, partner, picking);
      teDelivery.OrderType = orderType;
      teDeliveries.push(teDelivery);
    }

    // 4. Envia ao TE em lotes de 50
    const results = [];
    const BATCH = 50;

    for (let i = 0; i < teDeliveries.length; i += BATCH) {
      const batch = teDeliveries.slice(i, i + BATCH);
      const result = await teClient.createDeliveries(batch);
      results.push(result);

      // 5. Marca como sincronizado no ODOO
      const batchOrderNums = batch.map(d => d.OrderNumber);
      const syncedSo = saleOrders.filter(so =>
        batchOrderNums.includes(so.name) || batchOrderNums.includes(`WH-${so.id}`)
      );
      const syncedPickings = pickings.filter(p =>
        batchOrderNums.includes(p.origin) || batchOrderNums.includes(`WH-${p.id}`)
      );

      if (syncedSo.length > 0) {
        await odooClient.markSaleOrdersSynced(
          syncedSo.map(s => s.id),
          batchOrderNums[0],
          orderType
        );
      }
      if (syncedPickings.length > 0) {
        await odooClient.markPickingsSynced(
          syncedPickings.map(p => p.id),
          batchOrderNums[0]
        );
      }
    }

    logger.info(`Enviadas ${teDeliveries.length} entregas ao TE`, { results: results.length });
    res.json({
      success: true,
      sent: teDeliveries.length,
      batches: results.length,
      results,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// POST /api/deliveries/sync-unsynced — Busca e envia pedidos pendentes
// -------------------------------------------------------
router.post('/sync-unsynced', async (req, res, next) => {
  try {
    const { limit = 50, orderType = 1 } = req.body;

    // Busca pedidos de venda nao sincronizados
    const saleOrders = await odooClient.getUnsyncedSaleOrders(limit);

    if (saleOrders.length === 0) {
      return res.json({ success: true, sent: 0, message: 'Nenhum pedido pendente' });
    }

    // Busca pickings nao sincronizados
    const pickings = await odooClient.getUnsyncedPickings(limit);

    // Delega para a rota /send
    req.body = {
      orderIds: saleOrders.map(o => o.id),
      pickingIds: pickings.map(p => p.id),
      orderType,
    };
    return await router.handle(req, res, next);
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// GET /api/deliveries/status/:orderNumber — Consulta situacao no TE
// -------------------------------------------------------
router.get('/status/:orderNumber', async (req, res, next) => {
  try {
    const { orderNumber } = req.params;

    const result = await teClient.getDeliveries({ orderNumber, page: 1 });
    const delivery = result?.Result?.[0] || null;

    if (!delivery) {
      throw new AppError(`Entrega ${orderNumber} nao encontrada no TE`, 404);
    }

    const mapped = Mapper.teToOdooPicking(delivery);

    // Atualiza no ODOO se existir
    const picking = await odooClient.findPickingByTeId(orderNumber);
    if (picking) {
      await odooClient.updatePickingTeData(picking.id, mapped);
    }

    const saleOrder = await odooClient.findSaleOrderByTeId(orderNumber);
    if (saleOrder) {
      await odooClient.updateSaleOrderTeData(saleOrder.id, Mapper.teToOdooSaleOrder(delivery));
    }

    res.json({
      success: true,
      orderNumber,
      situation: mapped.situation,
      situationLabel: mapped.situationLabel,
      trackingCode: mapped.trackingCode,
      driverName: mapped.driverName,
      odooUpdated: !!(picking || saleOrder),
      raw: delivery,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// GET /api/deliveries/occurrences/:orderNumber — Consulta ocorrencias
// -------------------------------------------------------
router.get('/occurrences/:orderNumber', async (req, res, next) => {
  try {
    const { orderNumber } = req.params;

    const result = await teClient.getDeliveriesWithOccurrence({ orderNumber, page: 1 });
    const delivery = result?.Result?.[0] || null;

    if (!delivery) {
      throw new AppError(`Ocorrencia de ${orderNumber} nao encontrada`, 404);
    }

    const mapped = Mapper.teToOdooPicking(delivery);

    res.json({
      success: true,
      orderNumber,
      occurrenceDescription: delivery.OccurrenceDescription || delivery.occurrenceDescription,
      occurrenceDate: delivery.OccurrenceDate || delivery.occurrenceDate,
      situation: mapped.situation,
      situationLabel: mapped.situationLabel,
      raw: delivery,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// PUT /api/deliveries/edit — Edita entregas no TE
// -------------------------------------------------------
router.put('/edit', async (req, res, next) => {
  try {
    const { deliveries } = req.body;
    if (!deliveries?.length) {
      throw new AppError('Informe o array "deliveries"', 400);
    }

    const result = await teClient.editDeliveries(deliveries);
    res.json({ success: true, result });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// DELETE /api/deliveries/cancel — Cancela entregas no TE
// -------------------------------------------------------
router.delete('/cancel', async (req, res, next) => {
  try {
    const { orders } = req.body;
    if (!orders?.length) {
      throw new AppError('Informe o array "orders" com OrderNumber e OrderType', 400);
    }

    const result = await teClient.cancelDeliveries(orders);
    res.json({ success: true, result });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// GET /api/deliveries/situations — Lista situacoes disponiveis
// -------------------------------------------------------
router.get('/situations', async (req, res, next) => {
  try {
    const situations = await teClient.getSituations();
    res.json({ success: true, situations });
  } catch (err) {
    next(err);
  }
});

// -------------------------------------------------------
// GET /api/deliveries/pull — Puxa status de todas entregas e atualiza ODOO
// -------------------------------------------------------
router.get('/pull', async (req, res, next) => {
  try {
    const { dateFrom, dateTo, situation } = req.query;

    const params = { page: 1 };
    if (dateFrom) params.dateFrom = dateFrom;
    if (dateTo) params.dateTo = dateTo;
    if (situation) params.situation = parseInt(situation, 10);

    // Busca todas as paginas
    const allDeliveries = await teClient.fetchAllPages('/api/Entregas', params);

    let updated = 0;
    let notFound = 0;

    for (const d of allDeliveries) {
      const orderNum = d.OrderNumber || d.orderNumber;
      const picking = await odooClient.findPickingByTeId(orderNum);

      if (picking) {
        const mapped = Mapper.teToOdooPicking(d);
        await odooClient.updatePickingTeData(picking.id, mapped);
        updated++;
      } else {
        const so = await odooClient.findSaleOrderByTeId(orderNum);
        if (so) {
          await odooClient.updateSaleOrderTeData(so.id, Mapper.teToOdooSaleOrder(d));
          updated++;
        } else {
          notFound++;
        }
      }
    }

    res.json({
      success: true,
      totalFetched: allDeliveries.length,
      updatedInOdoo: updated,
      notFoundInOdoo: notFound,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;