// ============================================================
// src/routes/health.js — Health check
// ============================================================
const express = require('express');
const router = express.Router();
const env = require('../config/env');

router.get('/', async (req, res) => {
  const checks = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: env.nodeEnv,
    version: '1.0.0',
    services: {},
  };

  // Testa conexao TE (sem autenticar, so verifica se o host responde)
  try {
    const teClient = require('../services/tudoentregue');
    const startTime = Date.now();
    await teClient._request('GET', '/api/Entregas/Situacao');
    checks.services.tudoentregue = {
      status: 'ok',
      latencyMs: Date.now() - startTime,
    };
  } catch (err) {
    checks.services.tudoentregue = {
      status: 'error',
      message: err.message?.substring(0, 100),
    };
  }

  // Testa conexao ODOO
  try {
    const odooClient = require('../services/odoo');
    const startTime = Date.now();
    await odooClient.authenticate();
    checks.services.odoo = {
      status: 'ok',
      latencyMs: Date.now() - startTime,
      uid: odooClient.uid,
    };
  } catch (err) {
    checks.services.odoo = {
      status: 'error',
      message: err.message?.substring(0, 100),
    };
  }

  // Se algum servico criticos falhou, retorna 503
  const allOk = Object.values(checks.services).every(s => s.status === 'ok');
  res.status(allOk ? 200 : 503).json(checks);
});

module.exports = router;