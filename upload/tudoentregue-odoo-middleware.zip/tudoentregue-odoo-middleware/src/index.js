// ============================================================
// src/index.js — Entry point do middleware TE <-> ODOO
// ============================================================
require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const env = require('./config/env');
const logger = require('./utils/logger');

// Middleware
const { apiKeyAuth, teWebhookAuth } = require('./middleware/auth');
const { errorHandler, notFound } = require('./middleware/errorHandler');

// Routes
const deliveryRoutes = require('./routes/delivery');
const driverRoutes = require('./routes/driver');
const webhookRoutes = require('./routes/webhook');
const healthRoutes = require('./routes/health');

// -------------------------------------------------------
// Express App
// -------------------------------------------------------
const app = express();

// Security
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());

// Body parser (1MB max — limite da API TE)
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging
app.use(morgan('combined', {
  skip: (req) => req.path === '/health',
}));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 200,
  message: { error: 'Muitas requisicoes. Tente novamente em 15 minutos.' },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', apiLimiter);

// -------------------------------------------------------
// ROTAS PUBLICAS (sem autenticacao)
// -------------------------------------------------------
app.use('/health', healthRoutes);

// -------------------------------------------------------
// WEBHOOK (autenticacao via headers TE)
// -------------------------------------------------------
app.use('/webhook', webhookRoutes);

// -------------------------------------------------------
// ROTAS DA API (autenticacao via X-API-Key)
// -------------------------------------------------------
app.use('/api/deliveries', apiKeyAuth, deliveryRoutes);
app.use('/api/drivers', apiKeyAuth, driverRoutes);

// Rota raiz — informacoes da API
app.get('/', (req, res) => {
  res.json({
    name: 'TudoEntregue-ODOO Middleware',
    version: '1.0.0',
    environment: env.nodeEnv,
    endpoints: {
      health: 'GET  /health',
      webhook: 'POST /webhook/tudoentregue',
      deliveries: {
        send:          'POST   /api/deliveries/send',
        syncUnsynced:  'POST   /api/deliveries/sync-unsynced',
        status:        'GET    /api/deliveries/status/:orderNumber',
        occurrences:   'GET    /api/deliveries/occurrences/:orderNumber',
        edit:          'PUT    /api/deliveries/edit',
        cancel:        'DELETE /api/deliveries/cancel',
        situations:    'GET    /api/deliveries/situations',
        pull:          'GET    /api/deliveries/pull',
      },
      drivers: {
        list: 'GET /api/drivers',
      },
    },
  });
});

// -------------------------------------------------------
// Error handling (deve ser o ultimo)
// -------------------------------------------------------
app.use(notFound);
app.use(errorHandler);

// -------------------------------------------------------
// START
// -------------------------------------------------------
async function start() {
  try {
    // Autentica no ODOO ao iniciar
    logger.info('Autenticando no ODOO...');
    const odooClient = require('./services/odoo');
    await odooClient.authenticate();

    app.listen(env.port, () => {
      logger.info(`Middleware TE-ODOO rodando na porta ${env.port}`);
      logger.info(`Ambiente: ${env.nodeEnv}`);
      logger.info(`Webhook URL: ${env.nodeEnv === 'production'
        ? 'Configure no portal TE > Empresa > Webhook'
        : `http://localhost:${env.port}/webhook/tudoentregue`
      }`);
    });
  } catch (err) {
    logger.error('Falha ao iniciar o middleware', { error: err.message });
    process.exit(1);
  }
}

start();

module.exports = app;