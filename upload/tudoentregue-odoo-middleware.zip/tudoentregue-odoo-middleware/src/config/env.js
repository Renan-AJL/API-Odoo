// ============================================================
// src/config/env.js — Validacao e centralizacao das env vars
// ============================================================
const required = (key) => {
  const val = process.env[key];
  if (!val) {
    throw new Error(`ENV obrigatória ausente: ${key}`);
  }
  return val;
};

const optional = (key, fallback) => process.env[key] || fallback;

module.exports = {
  // Server
  port: optional('PORT', '3000'),
  nodeEnv: optional('NODE_ENV', 'development'),
  apiSecretKey: required('API_SECRET_KEY'),

  // TudoEntregue
  te: {
    baseUrl: required('TE_API_BASE_URL'),
    appKey: required('TE_APPKEY'),
    requesterKey: required('TE_REQUESTER_KEY'),
    pageSize: parseInt(optional('TE_PAGE_SIZE', '50'), 10),
    pageIntervalMs: parseInt(optional('TE_PAGE_INTERVAL_MS', '5000'), 10),
    maxEmptyPages: parseInt(optional('TE_MAX_EMPTY_PAGES', '10'), 10),
  },

  // ODOO
  odoo: {
    baseUrl: required('ODOO_BASE_URL'),
    db: required('ODOO_DB_NAME'),
    apiKey: required('ODOO_API_KEY'),
  },

  // Redis (opcional — fila Bull)
  redisUrl: optional('REDIS_URL', null),

  isDev: optional('NODE_ENV', 'development') === 'development',
};