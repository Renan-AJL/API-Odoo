// ============================================================
// src/config/constants.js — Codigos de situacao e constantes TE
// ============================================================

/**
 * Codigos de situacao TudoEntregue (campo Situation)
 * Consulte: /api/Entregas/Situacao
 *
 * DESCONTINUADOS: 2 (Reiniciada), 4 (Pausada), 7 (Finalizada)
 * CANCELADA: 8 (Cancelada pela torre ou motorista)
 * TRANSFERIDA: 11
 */
const SITUATION = {
  AGUARDANDO: 0,           // Aguardando
  EM_ROTA: 1,              // Em Rota
  // 2 - Reiniciada (descontinuado)
  ENTREGUE: 3,             // Entregue
  // 4 - Pausada (descontinuado)
  NAO_ENTREGUE: 5,         // Nao Entregue
  PARCIAL: 6,              // Entrega Parcial
  // 7 - Finalizada (descontinuado)
  CANCELADA: 8,            // Cancelada
  ATRASADA: 9,             // Atrasada
  EM_SEPARACAO: 10,        // Em Separacao
  TRANSFERIDA: 11,         // Transferida
  BAIXADA: 12,             // Baixada
};

const SITUATION_LABELS = {
  [SITUATION.AGUARDANDO]: 'Aguardando',
  [SITUATION.EM_ROTA]: 'Em Rota',
  [SITUATION.ENTREGUE]: 'Entregue',
  [SITUATION.NAO_ENTREGUE]: 'Nao Entregue',
  [SITUATION.PARCIAL]: 'Entrega Parcial',
  [SITUATION.CANCELADA]: 'Cancelada',
  [SITUATION.ATRASADA]: 'Atrasada',
  [SITUATION.EM_SEPARACAO]: 'Em Separacao',
  [SITUATION.TRANSFERIDA]: 'Transferida',
  [SITUATION.BAIXADA]: 'Baixada',
};

/**
 * Mapeamento situacao TE -> estagio ODOO stock.picking
 */
const SITUATION_TO_ODOO_STATE = {
  [SITUATION.AGUARDANDO]: 'assigned',
  [SITUATION.EM_SEPARACAO]: 'assigned',
  [SITUATION.EM_ROTA]: 'confirmed',
  [SITUATION.ENTREGUE]: 'done',
  [SITUATION.NAO_ENTREGUE]: 'done',
  [SITUATION.PARCIAL]: 'done',
  [SITUATION.CANCELADA]: 'cancel',
  [SITUATION.TRANSFERIDA]: 'assigned',
  [SITUATION.BAIXADA]: 'done',
  [SITUATION.ATRASADA]: 'confirmed',
};

/** Situacoes que indicam entrega finalizada (nao voltam) */
const FINAL_SITUATIONS = new Set([
  SITUATION.ENTREGUE,
  SITUATION.NAO_ENTREGUE,
  SITUATION.PARCIAL,
  SITUATION.CANCELADA,
  SITUATION.BAIXADA,
]);

/** Tipos de ocorrencia TE mais comuns */
const OCCURRENCE_TYPES = {
  ENTREGA_REALIZADA: 1,
  DESTINATARIO_AUSENTE: 2,
  RECUSA: 3,
  ENDERECO_INCORRETO: 4,
  PROBLEMA_MERCADORIA: 5,
  OUTROS: 6,
  ACEITE_PARCIAL: 7,
  TRANSFERENCIA: 8,
};

/** Limites da API TE */
const API_LIMITS = {
  MAX_PAYLOAD_BYTES: 1 * 1024 * 1024,  // 1 MB
  MAX_ORDERS_PER_REQUEST: 50,
  PAGINATION_INTERVAL_MS: 5000,
  QUERY_BLOCK_DURATION_MS: 10 * 60 * 1000,  // 10 min
  MAX_EMPTY_CONSECUTIVE_PAGES: 10,
};

/** OrderType mais usados */
const ORDER_TYPES = {
  ENTREGA: 1,
  COLETA: 2,
  DEVOLUCAO: 3,
  TROCA: 4,
  OUTROS: 5,
};

module.exports = {
  SITUATION,
  SITUATION_LABELS,
  SITUATION_TO_ODOO_STATE,
  FINAL_SITUATIONS,
  OCCURRENCE_TYPES,
  API_LIMITS,
  ORDER_TYPES,
};