// ============================================================
// src/utils/logger.js — Winston logger estruturado
// ============================================================
const { createLogger, format, transports } = require('winston');
const { combine, timestamp, printf, colorize, errors } = format;

const logFormat = printf(({ level, message, timestamp: ts, stack, ...meta }) => {
  const base = `${ts} [${level}]: ${message}`;
  const extra = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : '';
  return stack ? `${base}\n${stack}${extra}` : `${base}${extra}`;
});

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: combine(
    errors({ stack: true }),
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    logFormat,
  ),
  transports: [
    new transports.Console({
      format: combine(colorize(), logFormat),
    }),
  ],
});

module.exports = logger;