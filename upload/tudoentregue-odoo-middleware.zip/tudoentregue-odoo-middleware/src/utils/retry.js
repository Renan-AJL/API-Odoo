// ============================================================
// src/utils/retry.js — Retry com backoff exponencial
// ============================================================

/**
 * Executa fn com retry exponencial.
 * @param {Function} fn — funcao async que retorna resultado
 * @param {Object} opts
 * @param {number}  opts.maxRetries    - tentativas (default 3)
 * @param {number}  opts.baseDelay     - delay base em ms (default 1000)
 * @param {number}  opts.maxDelay      - delay maximo em ms (default 30000)
 * @param {Function} opts.shouldRetry  - (err) => bool (default: true)
 * @returns {Promise<*>}
 */
async function retryWithBackoff(fn, opts = {}) {
  const {
    maxRetries = 3,
    baseDelay = 1000,
    maxDelay = 30000,
    shouldRetry = () => true,
  } = opts;

  let lastError;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const canRetry = attempt < maxRetries && shouldRetry(err);
      if (!canRetry) throw err;

      const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
      const jitter = delay * (0.5 + Math.random() * 0.5);
      await new Promise((r) => setTimeout(r, jitter));
    }
  }
  throw lastError; // unreachable, mas seguro
}

module.exports = { retryWithBackoff };